// Log message to the console
console.log("Welcome to the Community Portal");

// Show alert when the page is fully loaded
window.onload = function () {
  alert("The Community Portal has fully loaded!");
};
